﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9-3-2019
* CSC 253
* Winston Stoker 
* Create and array of 3 RetailItem objects. 
*/

namespace M1HW4_StokerWinston
{
    class Program
    {
        static void Main(string[] args)
        {
            StoreLibrary.RetailItem retail = new StoreLibrary.RetailItem();

            //Create an array 
            const int SIZE = 9; 
            StoreLibrary.RetailItem[] listItems = new StoreLibrary.RetailItem[SIZE];

            //Create object 
            listItems[0] = new StoreLibrary.RetailItem();
            listItems[1] = new StoreLibrary.RetailItem();
            listItems[2] = new StoreLibrary.RetailItem();
            listItems[3] = new StoreLibrary.RetailItem();
            listItems[4] = new StoreLibrary.RetailItem();
            listItems[5] = new StoreLibrary.RetailItem();
            listItems[6] = new StoreLibrary.RetailItem();
            listItems[7] = new StoreLibrary.RetailItem();
            listItems[8] = new StoreLibrary.RetailItem();
    
            //Assign value to object 
            listItems[0].ClothesDescription = "Jacket ";
            listItems[1].ClothesOnHand = 12;
            listItems[2].ClothesPrice = 59.95;
            listItems[3].ClothesDescription = "Jeans";
            listItems[4].ClothesOnHand = 20;
            listItems[5].ClothesPrice = 34.95;
            listItems[6].ClothesDescription = "Shirt";
            listItems[7].ClothesOnHand = 40;
            listItems[8].ClothesPrice = 24.95;

            Console.WriteLine("Description " + "\tUnits on Hand" + "\tPrice");
            Console.WriteLine("--------------------------------------");

            for (int index = 0; index < SIZE; index++)
            {    
                Console.WriteLine(listItems[index].ClothesDescription
                       + "\t\t" + listItems[index].ClothesOnHand
                       + "\t\t" + listItems[index].ClothesPrice); 
            }       
            Console.ReadLine(); 
        }
    }
}
