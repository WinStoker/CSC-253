﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoreLibrary
{
    public class RetailItem
    {
       
        public RetailItem()
        {
            ClothesDescription = "";
            ClothesOnHand = 0;
            ClothesPrice = 0;
        }
        //CONSTRUCTOR
        public RetailItem(string clothesDescription, int clothesOnHand, double clothesPrice)
        {
            ClothesDescription = clothesDescription;
            ClothesOnHand      = clothesOnHand;
            ClothesPrice       = clothesPrice;
        }
        //PROPERTIES 
        public string ClothesDescription
        {
            get;
            set; 
        }
        public int ClothesOnHand
        {
            get;
            set;
        }
        public double ClothesPrice
        {
            get;
            set;
        }
    }
}
