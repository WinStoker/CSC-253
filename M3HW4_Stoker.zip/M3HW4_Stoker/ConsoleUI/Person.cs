﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleUI
{
    public class Person
    {
        public static List<Person> people = new List<Person>();

        #region Fields
        public Person()
        {
            FirstName = "";
            LastName = "";
           
        }
        #endregion

        #region Properties
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }

        #endregion

        #region Constructors
        public Person(string firstName, string lastName, int age)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age; 
        }
        #endregion

        public void ReadFromFile()
        {
            try
            {
                using (StreamReader fileReader = new StreamReader("UserInformation.txt"))
                {
                    while (!fileReader.EndOfStream)
                    {
                        var line = fileReader.ReadLine();
                        var values = line.Split(',');

                        Person.people.Add(new Person(values[1], values[0], int.Parse(values[2]) ));
                    }
                    foreach (Person name in Person.people)
                    {
                        Console.WriteLine("Last  Name : " + name.LastName);
                        Console.WriteLine("First Name : " + name.FirstName);
                        Console.WriteLine("Age        : " + name.Age);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }

}
