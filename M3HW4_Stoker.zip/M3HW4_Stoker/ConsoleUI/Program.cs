﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/**
* 8 OCT 2019
* CSC 253
* Winston Stoker 
* Read data from file, assing information to a class, display data
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();

            person.ReadFromFile();

            Console.ReadLine();     
        }       
    }
}

/*This program requires that you complete "Write Class Information to File", if you have not completed that successfully then this program can not be completed.
 * This program should read the information from the file named "UserInformation" then load that information into a class named "Person".
 * Once it has done that then it should display all the class information in a formated way to the screen of the application. 
 */
