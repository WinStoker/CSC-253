﻿namespace WindowsFormUI
{


    partial class EmployeeDataSet
    {
    }
}

namespace WindowsFormUI.EmployeeDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
