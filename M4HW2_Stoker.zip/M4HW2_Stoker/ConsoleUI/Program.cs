﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductionLibrary;

/**
* 22 OCT 2019
* CSC 253
* Winston Stoker
* This program does....
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeBuild employee = new EmployeeBuild();

            EmployeeBuild.GetEmployeeInfo();
        }

    }

}
