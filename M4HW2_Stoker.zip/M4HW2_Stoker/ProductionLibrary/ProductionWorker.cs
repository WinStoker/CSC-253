﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductionLibrary
{
    public class ProductionWorker : Employee
    {
        #region Field
        private string _shiftNumber;
        private double _hourlyPayRate;   
        #endregion

        #region Constructor 
        public ProductionWorker()
        {
            _shiftNumber = "";
            _hourlyPayRate = 0; 
        }
        #endregion

        #region Property
        public string Shift
        {
            get { return _shiftNumber; }
            set { _shiftNumber = value; }
        }
        public double HourlyPayRate
        {
            get { return _hourlyPayRate; }
            set { _hourlyPayRate = value; }
        }
        #endregion
        
    }
}
