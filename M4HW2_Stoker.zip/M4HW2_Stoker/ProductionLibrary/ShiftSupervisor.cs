﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductionLibrary
{
    public class ShiftSupervisor : Employee
    {
        #region Fields
        private string _annualSalary;
        private string _annualProductionBonus;
        #endregion

        #region Constructor 
        public ShiftSupervisor()
        {
            _annualSalary = "";
            _annualProductionBonus = "";
        }
        #endregion

        #region Properties
        public string AnnualSalary
        {
            get { return _annualSalary;  }
            set { _annualSalary = value; }
        }
        public string AnnualProductionBonus
        {
            get { return _annualSalary; }
            set { _annualSalary = value; }
        }

        #endregion

    }
}
