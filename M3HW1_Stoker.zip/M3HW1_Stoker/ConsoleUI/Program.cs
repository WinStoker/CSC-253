﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/**
* 9-24-2019
* CSC 253
* Winston Stoker 
* User enters in a range of numbers, program writes range randomly from(1-100) to a file.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int number;
                int userNumber;
                int count = 1;
                Random rand = new Random(); // Create a random object 
                StreamWriter outputFile; //object used to write to a file
                

                Console.WriteLine("How many random numbers from (1-100) would you like to create and write to a file? "); // Get # from user
                Console.Write(">> ");
                string input = Console.ReadLine();
                if (int.TryParse(input, out userNumber)) // Parse from string to int 
                { }

                Console.WriteLine("Enter a file name to save as: "); // Have user enter a file name
                input = Console.ReadLine();
             
                outputFile = File.AppendText(input + ".txt"); // allow user to name saved file 

                while (count <= userNumber) //counter for # user number
                {
                    number = rand.Next(100); // Create a random number from (1-100)
                    outputFile.WriteLine(number);
                    count++;

                }
                outputFile.Close(); // Close file after writing 

            }
            catch (Exception ex) // Display error messages 
            {
                Console.WriteLine(ex.Message, ex.StackTrace);
            }

            Console.ReadLine();

        }
    }
}
