﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleUI.People
{
    public class Person
    {
        public Person()
        {
            FirstName = "";
            LastName = "";
            Age = 0;
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public Person(string firstName, string lastName, int age)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age;
        }
        public void GetUserInfo()
        {
            Console.WriteLine("What is your first name: ");
            Console.Write(">> ");
            FirstName = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("What is your last name: ");
            Console.Write(">> ");
            LastName = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("What is your age? ");
            Console.Write(">> ");
            Age = int.Parse(Console.ReadLine());
        }
        public void WriteToFile()
        {
            try
            {
                StreamWriter outputFile;
                outputFile = File.AppendText("UserInformation.txt");

                outputFile.WriteLine("Last Name : " + LastName);
                outputFile.WriteLine("First Name: " + FirstName);
                outputFile.WriteLine("Age : " + Age);

                Console.WriteLine("");
                Console.WriteLine("Your information has been written to a .txt file! (UserInformation.txt)");

                outputFile.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);

            }
        }
    }
}
