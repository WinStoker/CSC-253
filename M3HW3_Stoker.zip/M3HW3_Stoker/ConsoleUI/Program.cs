﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleUI.People;

/**
* 8 Oct 2019
* CSC 253
* Winston Stoker 
* Program takes user input from a class and writes it to a txt file.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();

            person.GetUserInfo();
            person.WriteToFile();

            Console.ReadLine();
        }

    }
}

/*
 * Create a program that has a "Person" class. This class's information is filled in by the user. 
 * Then the program should read and save all this information from the class (not as it is put in) and save it to a file named "UserInformation".
 */
