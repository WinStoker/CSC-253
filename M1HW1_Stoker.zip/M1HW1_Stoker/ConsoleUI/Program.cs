﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 8-23-2019
* CSC 253
* Winston Stoker 
* Application predicts the approximate size of a population of organisms.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal numOrganisms;
            decimal dailyIncrease;
            double multiplyDays;
            int days = 1;

            Console.WriteLine("Please enter the starting number of organisms: ");
            string input = Console.ReadLine();
            if (decimal.TryParse(input, out numOrganisms))
            { }

            Console.WriteLine("Enter the average daily increase percentage(%): ");
            input = Console.ReadLine();
            if (decimal.TryParse(input, out dailyIncrease))
            { }

            Console.WriteLine("Enter the number of days to multiply: ");
            input = Console.ReadLine();
            if (double.TryParse(input, out multiplyDays))
            { }

            //******Display 
            Console.WriteLine("");
            Console.WriteLine("Day" + "\t Approximate Population");
            Console.WriteLine("-------------------------------------------");

            //Increments the days up to 10 
            for (int count = 1; count <= multiplyDays; count+= days)
            {
                numOrganisms = (numOrganisms * (dailyIncrease/100) + numOrganisms);         
                Console.WriteLine(count + "\t\t" + numOrganisms);
            }
            Console.WriteLine("-------------------------------------------");
            //*****Display

            Console.ReadLine();



        }
    }
}
