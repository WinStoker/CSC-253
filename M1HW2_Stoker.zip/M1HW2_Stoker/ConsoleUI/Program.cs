﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 8-23-2019
* CSC 253
* Winston Stoker 
* Program calculates the total cost of a hospital stay.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            decimal daysInTheHospital;
            decimal medicationCharges;
            decimal labFees;
            decimal rehabCharges;
            decimal dayCharge = 0;
            decimal healthChargeTotal = 0;
            decimal overallTotal = 0;

            //******* Get information 
            Console.WriteLine("Number of days in the hospital: ");
            input = Console.ReadLine();
            if (decimal.TryParse(input, out daysInTheHospital))
            { }
            Console.WriteLine("The amount of medication charges: ");
            input = Console.ReadLine();
            if (decimal.TryParse(input, out medicationCharges))
            { }
            Console.WriteLine("The amount of lab fees: ");
            input = Console.ReadLine();
            if (decimal.TryParse(input, out labFees))
            { }
            Console.WriteLine("The amount of physical rehabilitation charges: ");
            input = Console.ReadLine();
            if (decimal.TryParse(input, out rehabCharges))
            { }
            //******

            Console.WriteLine("-------------Total-----------------");

            CalcStayCharges(daysInTheHospital, ref dayCharge);
            CalcMiscCharges(medicationCharges, labFees, rehabCharges, ref healthChargeTotal);
            CalcTotalCharges(ref dayCharge, ref healthChargeTotal, ref overallTotal);

            Console.WriteLine("-----------------------------------");

            Console.ReadLine();
        }
        public static decimal CalcStayCharges(decimal daysInHospital, ref decimal dayCharge)
        {
            dayCharge = daysInHospital * 350;
            Console.WriteLine($"Hospital Stay fee: ${dayCharge} ");
            return dayCharge;
        }

        public static decimal CalcMiscCharges(decimal medicationCharges, decimal labFees, decimal rehabCharges, ref decimal healthChargeTotal)
        {
            healthChargeTotal =  medicationCharges + labFees + rehabCharges;
            Console.WriteLine($"Health Care Cost: ${healthChargeTotal}");
            
            return healthChargeTotal;
        }
        public static void CalcTotalCharges(ref decimal dayCharge, ref decimal healthChargeTotal, ref decimal overallTotal)
        {
            //Calculate the total charges 
            overallTotal = dayCharge + healthChargeTotal;

            Console.WriteLine($"Overall cost: ${overallTotal}");       
        }
    }
}
