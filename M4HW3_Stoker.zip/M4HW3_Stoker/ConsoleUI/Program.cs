﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductionLibrary;

/**
* 28 OCT 2019
* CSC 253
* Winston Stoker
* This program...
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            
            EmployeeBuild employee = new EmployeeBuild();
            EmployeeBuild.GetEmployeeInfo();

        }
    }
}
/*
 * Change the fields from private 
 * Fix the single responsiblity in EmployeeBuild / create a seperate class
 * Create methods to be called 
 */