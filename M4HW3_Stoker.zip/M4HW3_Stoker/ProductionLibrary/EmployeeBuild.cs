﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductionLibrary
{
    public class EmployeeBuild
    {
        public static void GetEmployeeInfo()
        {
            string input;
            bool good = false;
            double hourlyPayRate;
            double monthlyBonusAmount;
            double reqTrainingHours;
            double trainingHoursAttended;

            ProductionWorker myEmployee = new ProductionWorker();
            TeamLeader myTeamLeader = new TeamLeader(); 

            Console.WriteLine("Enter your first and last name: ");
            Console.Write(">> ");
            myEmployee.Name = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("Enter your employee number: ");
            Console.Write(">> ");
            myEmployee.Number = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("Enter your shift (1st or 2nd): ");
            Console.Write(">> ");
            myEmployee.Shift = Console.ReadLine();

            Console.WriteLine("");
            do
            {
                Console.WriteLine("Enter your hourly pay rate: ");
                Console.Write(">> ");
                input = Console.ReadLine();
                if (double.TryParse(input, out hourlyPayRate))
                {
                    myEmployee.HourlyPayRate = hourlyPayRate;
                }
            } while (good == true);

            Console.WriteLine("");
            Console.WriteLine("Monthly Bonus Amount: ");
            Console.Write(">> ");
            input = Console.ReadLine();
            if (double.TryParse(input, out monthlyBonusAmount))
            {
                myTeamLeader.MonthlyBonusAmount = monthlyBonusAmount;
            }

            Console.WriteLine("");
            Console.WriteLine("Required Training Hours: ");
            Console.Write(">> ");
            input = Console.ReadLine();
            if (double.TryParse(input, out reqTrainingHours))
            {
                myTeamLeader.ReqTrainingHours = reqTrainingHours;
            }

            Console.WriteLine("");
            Console.WriteLine("Training Hours Attended: ");
            Console.Write(">> ");
            input = Console.ReadLine();
            if (double.TryParse(input, out trainingHoursAttended))
            {
                myTeamLeader.TrainingHoursAttended = trainingHoursAttended;
            }

            //Display input to user
            Console.WriteLine("--------------------------------------");
            Console.WriteLine($"Name:             {myEmployee.Name}  ");
            Console.WriteLine($"Employee Number:  {myEmployee.Number}");
            Console.WriteLine($"Shift:            {myEmployee.Shift} ");
            Console.WriteLine($"Hourly Pay Rate: ${myEmployee.HourlyPayRate}");


            //Display input to user
            Console.WriteLine("");
            Console.WriteLine("--------------------------------------");
            Console.WriteLine($"Monthly Bonus amount:     {myTeamLeader.MonthlyBonusAmount}");
            Console.WriteLine($"Required training hours:  {myTeamLeader.ReqTrainingHours}");
            Console.WriteLine($"Training Hours Attended:  {myTeamLeader.TrainingHoursAttended }");

            Console.ReadLine();
        }
    }
}
