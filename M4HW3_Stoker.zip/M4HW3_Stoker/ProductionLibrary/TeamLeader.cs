﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductionLibrary
{
    public class TeamLeader : ProductionWorker
    {
        #region Fields
        private double _monthlyBonusAmount;
        private double _reqTraingingHours;
        private double _trainingHoursAttended;
        #endregion

        #region Constructor 
        public TeamLeader()
        {
            _monthlyBonusAmount = 0;
            _reqTraingingHours = 0;
            _trainingHoursAttended = 0; 
        }
        #endregion

        #region Properties
        public double MonthlyBonusAmount
        {
            get { return _monthlyBonusAmount; }
            set { _monthlyBonusAmount = value; }
        }
        public double ReqTrainingHours
        {
            get { return _reqTraingingHours; }
            set { _reqTraingingHours = value; }
        }
            public double TrainingHoursAttended
        {
            get { return _trainingHoursAttended; }
            set { _trainingHoursAttended = value; }
        }

        #endregion

    }
}
