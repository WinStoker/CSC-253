﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductionLibrary
{
    public class Employee
    {// Fields don't need to be private 
        #region Field

        private string _employeeName;
        private string _employeeNumber;
        #endregion

        #region Constructor
        public Employee()
        {
            _employeeName = "";
            _employeeNumber = "";
        }
        #endregion

        #region Properties
        public string Name
        {
            get { return _employeeName; }
            set { _employeeName = value; }
        }

        public string Number
        {
            get { return _employeeNumber; }
            set { _employeeNumber = value; }
        }
        #endregion
    }
}
