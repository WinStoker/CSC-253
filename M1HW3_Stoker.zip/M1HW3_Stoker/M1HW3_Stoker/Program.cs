﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 8-29-2018
* CSC 253
* Winston Stoker 
* Demonstrate the class in an application that creates a Car object. 
*/


namespace M1HW3_Stoker
{
    public class Program
    {
        static void Main(string[] args)
        {
            CarLibrary.CarClass car = new CarLibrary.CarClass();
            bool exit = false;

            car.CarYear = 2015;
            car.CarMake = "Subaru";
            car.CarSpeed = 0;


            do
            {
                //Call the corresponding methods 
                DisplayMenu();
 
                string input = Console.ReadLine();

                //Decision making structure 
                switch (input)
                {
                    case "1":
                       
                        car.CarAccelerate(car.CarSpeed);
                        Console.WriteLine("Car Year : " + car.CarYear);
                        Console.WriteLine("Car Make : " + car.CarMake);
                        Console.WriteLine("Car Speed: " + car.CarSpeed + "mph");
                        break;

                    case "2":
                        car.CarBrake(car.CarSpeed);
                        Console.WriteLine("Car Year : " + car.CarYear);
                        Console.WriteLine("Car Make : " + car.CarMake);
                        Console.WriteLine("Car Speed: " + car.CarSpeed + "mph");
                        break;

                    case "3":
                        exit = true;
                        break;
                }         
            } while (exit == false); 

            Console.ReadLine();
        }
        public static void DisplayMenu()
        {
            //Menu for user to Accelerate, brake, or exit 
            Console.WriteLine("--------Menu----------");
            Console.WriteLine("1. Accelerate Car ");
            Console.WriteLine("2. Brake Car");
            Console.WriteLine("3. Exit Program");
            Console.WriteLine("----------------------");
            Console.Write(">>");
        }
    }
}
