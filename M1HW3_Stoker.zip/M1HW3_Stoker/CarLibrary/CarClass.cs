﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 8-29-2018
* CSC 253
* Winston Stoker 
* Demonstrate the class in an application that creates a Car object. 
*/



namespace CarLibrary
{
    public class CarClass
    {
        //Feild
        private int _carSpeed;

        //Default Constructor 
        public CarClass()
        {
            CarYear  = 0;
            CarMake  = "";
            CarSpeed = 0;
        }
        //Parameterized Constructor 
        public CarClass(int carYear, string carMake, int carSpeed)
        {
            CarYear  = carYear;
            CarMake  = carMake;
            CarSpeed = carSpeed;          
        }
        //Properties 
        public int CarYear
        { get;
          set;
        }
        public string CarMake
        {
            get;
            set;
        }
        public int CarSpeed
        {
            get
            {
                return _carSpeed;
            }
            set
            {
                _carSpeed = value;
            }           
        }
        //Accelerate method 
        public int CarAccelerate(int CarSpeed)
        {
            _carSpeed += 5;
            return CarSpeed; 
        }
        //Brake method
        public int CarBrake(int CarSpeed)
        {
            _carSpeed -= 5;
            return CarSpeed;
        }
    }
}
