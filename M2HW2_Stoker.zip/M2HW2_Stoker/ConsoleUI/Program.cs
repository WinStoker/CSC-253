﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9-9-19
* CSC 253
* Winston Stoker
* Display average number of letters in each word.
*/

namespace M12HW2_Stoker
{
    class Program
    {
        static void Main(string[] args)
        {
            int result = 0;
            string input = "";

            //Have user to enter a word or phrase to be counted 
            Console.WriteLine("Enter in a word or phrase (For example: four score and seven years ago) ");
            Console.Write(">> ");
            input = Console.ReadLine();

            //Call the method
            WordCount(ref result, ref input);

            //Display the results 
            Console.WriteLine($"The number in the string is: {result}" +
                              $"\nThe average number is: {input.Length / result}");

            Console.ReadLine();
        }
        public static int WordCount(ref int result, ref string input)
        {
            //Count the word 
            foreach (string y in input.Split(' '))
            {
                result++;
                //Return the number counted
            }
            return result;

        }
    }
}
