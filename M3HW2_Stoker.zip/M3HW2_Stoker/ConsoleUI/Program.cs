﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/**
* 9-26-2019
* CSC 253
* Winston Stoker 
* Program reads information from .txt file, specified by user. 
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int number;
                int userNumber;
                int count = 1;
                Random rand = new Random(); // Create a random object 
                StreamWriter outputFile; //object used to write to a file
                int randomNumbers;

                Console.WriteLine("How many random numbers from (1-100) would you like to create and write to a file? "); // Get # from user
                Console.Write(">> ");
                string input = Console.ReadLine();
                if (int.TryParse(input, out userNumber)) // Parse from string to int 
                { }

                Console.WriteLine("Enter a file name to save as: "); // Have user enter a file name
                Console.Write(">> ");
                input = Console.ReadLine();

                outputFile = File.AppendText(input + ".txt"); // allow user to name saved file 

                while (count <= userNumber) //counter for # user number
                {
                    number = rand.Next(100); // Generate a random number from (1-100)
                    outputFile.WriteLine(number);
                    count++;
                }
               
                outputFile.Close(); // Close file after writing 

                StreamReader inputFile; // Read file 
                string userFile;

                Console.WriteLine("What file would you like to load (Example: Test.txt) ");
                Console.Write(">> ");
                userFile = Console.ReadLine();
                
                inputFile = File.OpenText(userFile); // User specifies which .txt file to open.

                while (!inputFile.EndOfStream)// Display's all items in a file
                {
                    randomNumbers = int.Parse(inputFile.ReadLine());

                    Console.WriteLine(randomNumbers);
                }            
                inputFile.Close(); // Close file after reading 
            }
            catch (Exception ex)
            {// Display error messages 
                Console.WriteLine("");
                Console.WriteLine("Ooops.....Their seems to be an error!");
                Console.WriteLine(ex.Message, ex.StackTrace);
            }
            Console.ReadLine();
        }
    }
}
