﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductionLibrary;

/**
* 22 OCT 2019
* CSC 253
* Winston Stoker
* 
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeBuild worker = new EmployeeBuild();
            worker.GetEmployeeInfo();         
        }
    }
}
