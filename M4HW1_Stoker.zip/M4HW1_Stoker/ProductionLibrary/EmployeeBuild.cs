﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductionLibrary
{
    public class EmployeeBuild
    {
        public void GetEmployeeInfo()
        {
            string input;
            bool good = false;
            double hourlyPayRate;

            ProductionWorker myEmployee = new ProductionWorker();

            Console.WriteLine("Enter your first and last name: ");
            Console.Write(">> ");
            myEmployee.Name = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("Enter your employee number: ");
            Console.Write(">> ");
            myEmployee.Number = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("Enter your shift (1st or 2nd): ");
            Console.Write(">> ");
            myEmployee.Shift = Console.ReadLine();

            do
            {
                Console.WriteLine("");
                Console.WriteLine("Enter your hourly pay rate: ");
                Console.Write(">> ");
                input = Console.ReadLine();
                if (double.TryParse(input, out hourlyPayRate))
                {
                    myEmployee.HourlyPayRate = hourlyPayRate;
                }
            } while (good == true);

            //Display input to user
            Console.WriteLine("--------------------------------------");
            Console.WriteLine($"Name:             {myEmployee.Name}  ");
            Console.WriteLine($"Employee Number:  {myEmployee.Number}");
            Console.WriteLine($"Shift:            {myEmployee.Shift} ");
            Console.WriteLine($"Hourly Pay Rate: ${myEmployee.HourlyPayRate}");
            Console.ReadLine();
        }
    }
}
