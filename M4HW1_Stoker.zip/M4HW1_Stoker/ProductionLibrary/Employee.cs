﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductionLibrary
{
    public class Employee
    {
        #region Field
        
        private string _employeeName;
        private string _employeeNumber;
        #endregion

        #region Constructor
        public Employee()
        {
            _employeeName = "";
            _employeeNumber = "";
        }
        #endregion

        #region Property
        public string Name
        {
            get { return _employeeName; }
            set { _employeeName = value;}
        }
  
        public string Number
        {
            get { return _employeeNumber;  }
            set { _employeeNumber = value; }
        }
        #endregion
    }
}
