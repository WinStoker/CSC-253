﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9-10-2019 
* CSC 253
* Winston Stoker 
* Display the character that appears most frequently in the string. 
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int result = 0;
            string input;

            //Have user to enter a word or phrase to be counted 
            Console.WriteLine("Enter in a word or phrase (For example: four score and seven years ago) ");
            Console.Write(">> ");
            input = Console.ReadLine();

            //Call the method
            WordCount(ref result, ref input);

            //Display the results 
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine($"The number in the string is: {result}" +
                              $"\nThe average number is: {input.Length / result}");
            // Call the method                   
            MaxCount(ref input);

            Console.ReadLine();
        }
        public static int WordCount(ref int result, ref string input)
        {
            //Count the word 
            foreach (string y in input.Split(' '))
            {
                result++;
                //Return the number counted
            }
            return result;
        }
        public static void MaxCount(ref string input)
        {
            
            int[] count = new int[255];
            int index = 0;
            int max = 0;
            int charLength;
            int counter;

            //Get length of char
            charLength = input.Length;

            //Set array to 0 
            Array.Clear(count, 0, count.Length);

            //Read frequency of each characters 
            while (index < charLength)
            {
                counter = input[index];
                count[counter] += 1;
                index++;
            }
            // Console.Write("{0}  ",(char)65);       
            for (index = 0; index < 255; index++)
            {
                if (index != 32)
                {
                    if (count[index] > count[max])
                        max = index;
                }
            }
            Console.Write("The Highest frequency of character '{0}' is appearing for a number of {1} times! ", (char)max, count[max]);
        }
    }    
}
